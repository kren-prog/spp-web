import React from 'react';
import Table from 'react-bootstrap/Table';
import { Pencil, Trash } from 'react-bootstrap-icons';
import "../assets/styles/table.css";
import SweetAlert from './sweetAlert';

function BasicTable() {
    const [alertResponse, setAlertResponse] = React.useState(null);

    const handleAlertResponse = (response) => {
        setAlertResponse(response);
      };

    return (
        <Table striped bordered hover responsive>
            <thead>
                <tr>
                    <th>Codigo</th>
                    <th>Tipo cadena</th>
                    <th>Tipo entero</th>
                    <th>Descripcion</th>
                    <th>Secuencia</th>
                    <th>Atributo N1</th>
                    <th>Atributo N2</th>
                    <th>Atributo N3</th>
                    <th>Atributo N4</th>
                    <th>Atributo C1</th>
                    <th>Atributo C2</th>
                    <th>Atributo C3</th>
                    <th>Atributo C4</th>
                    <th className="fixed-column">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                    <td>1</td>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                    <td>1</td>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td className="fixed-column">
                        <div className="p-2 icons">
                            <a href='/'><Pencil color="royalblue" size={24} title="Editar" /></a>
                            <SweetAlert
                                title="Esta seguro?"
                                text="Se eliminara el item."
                                icon="warning"
                                typebtn="delete"
                            />
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                    <td>2</td>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                    <td>2</td>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                    <td>@fat</td>
                    <td className="fixed-column">
                        <div className="p-2 icons">
                            <a href='/'><Pencil color="royalblue" size={24} title="Editar" /></a>
                            <SweetAlert onAlertResponse={handleAlertResponse}
                                title="Esta seguro?"
                                text="Se eliminara el item."
                                icon="warning"
                                typebtn="delete"
                            />
                            <p>Response {alertResponse}</p>
                        </div>
                    </td>
                </tr>

            </tbody>
        </Table>


    );
}

export default BasicTable;